//
//  CustomARViewRepresentable.swift
//  AROFFSETAPP
//
//  Created by Darshan Gummadi on 9/25/23.
//

import SwiftUI


struct CustomARViewRepresentable: UIViewRepresentable{
    func makeUIView(context: Context) -> some CustomARView {
        return CustomARView()
    }
    func updateUIView(_ uiView: UIViewType, context: Context) {
    }
}

